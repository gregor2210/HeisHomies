#pragma once

#include "elevator_io_types.h"


ElevInputDevice elevio_getInputDevice(void);
ElevOutputDevice elevio_getOutputDevice(void);